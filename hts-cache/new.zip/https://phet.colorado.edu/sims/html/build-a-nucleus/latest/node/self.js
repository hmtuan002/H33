<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml" xmlns:esi="http://java.sun.com/JSP/Page" xml:lang="en" lang="en">
<head>
  <!-- @formatter:off -->
  <!-- Google Tag Manager -->

  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag() { window.dataLayer.push(arguments); }
    gtag( 'consent', 'default', {
      ad_storage: 'denied',
      analytics_storage: 'granted',
    } );

    (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
      new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
  })(window,document,'script','dataLayer','GTM-WLNGBXD');

  </script>
  <!-- End Google Tag Manager -->
  <!-- @formatter:on -->

  <meta http-equiv="Content-type" content="text/html;charset=UTF-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  
  <title>The requested page could not be found.</title>
  
  
  <link rel="stylesheet" href="/css/font-awesome/css/font-awesome.min-4.7.css">
  <link rel="stylesheet" type="text/css" href="https://phet.colorado.edu/css/phet-v102-min.css"/>

  <!-- class edu.colorado.phet.website.content.NotFoundPage -->
  <!-- host phet.colorado.edu -->
  

  <script src="https://apis.google.com/js/platform.js" async defer></script>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
      href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
      rel="stylesheet">

  <script type="text/javascript">
    function initBreakpoint() {
      var body = document.querySelector( 'body' );
      var menuParents = document.querySelectorAll( '#page-nav-menu ul[role=menubar] .nav-menu-parent-text' );

      if ( body && menuParents ) {
        clearInterval( isLargeViewInterval );
        window.phet = window.phet || {};
        window.phet.cssBreakpoint = 40 + // page header container padding
                                    220 + // phet and cu logos
                                    75 + // search and user menus
                                    ( body.className.indexOf( 'rtl' ) >= 0 ? 30 : 0 ) + // RTL languages need to break 30 pixels earlier somehow
                                    Array.prototype.slice.call( menuParents )
                                        .map( function( item ) {
                                          return item.offsetWidth
                                                 - parseInt( window.getComputedStyle( item ).paddingRight )
                                                 - parseInt( window.getComputedStyle( item ).paddingLeft )
                                                 + 22; // 22 is horizontal padding + horizontal margin on nav-menu-parent-text in wide view
                                        } )
                                        .reduce( function( accumulator, currentItem ) { return accumulator + currentItem; }, 0 ); // dropdown menu width, flexible due to translations
        const mediaString = '(min-width: ' + window.phet.cssBreakpoint + 'px)';
        window.phet.isLargeView = function() {
          return window.matchMedia( mediaString ).matches;
        };

        document.body.className = document.body.className.replace( 'pre-load', window.phet.isLargeView() ? 'wide' : 'narrow' );
        document.getElementById( 'page-header-container-wrapper' ).className = window.phet.isLargeView() ? 'expanded' : 'collapsed';
      }
    }

    var isLargeViewInterval = setInterval( initBreakpoint, 50 );
  </script>

    <script type="text/javascript">window.phet = window.phet || {};window.phet.phetLocale = "en";var phetSimulationString = "{0} (simulation)";</script>
  
        <meta property="og:site_name" content="PhET"/><meta property="twitter:site" content="@PhETsims"/><meta property="og:title" content="PhET Interactive Simulations"/><meta property="twitter:title" content="PhET Interactive Simulations"/><meta property="og:url" content="https://phet.colorado.edu/error/404"/><meta property="twitter:card" content="summary"/><meta property="og:image" content="https://phet.colorado.edu/images/phet-social-media-logo.png"/><meta property="twitter:image" content="https://phet.colorado.edu/images/phet-social-media-logo.png"/><meta property="og:description" content="Founded in 2002 by Nobel Laureate Carl Wieman, the PhET Interactive Simulations project at the University of Colorado Boulder creates free interactive math and science simulations. PhET sims are based on extensive education <a {{0}}>research</a> and engage students through an intuitive, game-like environment where students learn through exploration and discovery."/><meta property="twitter:description" content="Founded in 2002 by Nobel Laureate Carl Wieman, the PhET Interactive Simulations project at the University of Colorado Boulder creates free interactive math and science simulations. PhET sims are based on extensive education <a {{0}}>research</a> and engage students through an intuitive, game-like environment where students learn through exploration and discovery."/>
    </head>
<body dir="ltr" class="ltr pre-load">
<!-- @formatter:off -->
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WLNGBXD"
                  height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<!-- @formatter:on -->

<div id="skipNav">
  <a href="#page-content" accesskey="0" id="skipper" tabindex="1">
    Skip to Main Content
  </a>
</div>



<div id="page-header" class="ltr">

  

  <div id="page-header-container-wrapper">
    <header id="page-header-container" role="banner">
      <div id="page-header-left">
        <a href="/" class="phet-logo-link">
          <div class="phet-logo">
            <img src="/images/phet-logo-trademarked.png"
                 alt="PhET Home Page"
                 title="Go to the PhET home page"
            />
          </div>
        </a>
        <div class="cu-logo">
          <a href="http://www.colorado.edu" target="_blank">
            <div class="cu-logo-image-clip">
              <img src="/images/logos/cu_logo.png" alt="University of Colorado"/>
            </div>
          </a>
        </div>
      </div>

      <a id="collapsible-menu-toggle" role="button" aria-haspopup="menu" aria-expanded="false" aria-label="Toggle Primary Menu">
        <div id="toggle-container">
          <span id="nw-rotate" class="rotate">
            <span id="nw-translate" class="line"></span>
          </span>
          <span id="ne-rotate" class="rotate">
            <span id="ne-translate" class="line"></span>
          </span>
          <span id="sw-rotate" class="rotate">
            <span id="sw-translate" class="line"></span>
          </span>
          <span id="se-rotate" class="rotate">
            <span id="se-translate" class="line"></span>
          </span>
          <span id="east-center-line" class="line center-line"></span>
          <span id="west-center-line" class="line center-line"></span>
        </div>
      </a>

      <div id="page-header-menus" class="ltr">
        <div id="collapsible-menu">
          <div id="search-container-mobile" role="search"></div>
          <nav id="page-nav-menu" role="navigation">
  <span class="screenReaderOnlyInvoked">
    Website Navigation
  </span>
  <ul role="menubar">
    <li class="nav-menu-item">
      <a class="nav-menu-parent has-menu nav0" role="menuitem" id="nav.simulations" aria-haspopup="menu" aria-expanded="false">
        <span class="nav-menu-parent-text">Simulations</span>
      </a>
      <div class="nav-menu-children" aria-hidden="true">
        <ul role="menu" aria-labelledby="nav.simulations">
          <li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-allSimulations" href="/en/simulations/filter?type=html">
            <span class="nav-menu-child-text">All Sims</span></a></li><li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-physics" href="/en/simulations/filter?subjects=physics&amp;type=html">
            <span class="nav-menu-child-text">Physics</span></a></li><li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-math-and-statistics" href="/en/simulations/filter?subjects=math-and-statistics&amp;type=html">
            <span class="nav-menu-child-text">Math & Statistics</span></a></li><li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-chemistry" href="/en/simulations/filter?subjects=chemistry&amp;type=html">
            <span class="nav-menu-child-text">Chemistry</span></a></li><li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-earth-and-space" href="/en/simulations/filter?subjects=earth-and-space&amp;type=html">
            <span class="nav-menu-child-text">Earth & Space</span></a></li><li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-biology" href="/en/simulations/filter?subjects=biology&amp;type=html">
            <span class="nav-menu-child-text">Biology</span></a></li><li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-simulations-translated" href="/en/simulations/translated">
            <span class="nav-menu-child-text">Translated Sims</span></a></li><li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-simulations-studio" href="/en/simulations/customize">
            <span class="nav-menu-child-text">Customizable Sims</span></a></li>
        </ul>
      </div>
    </li><li class="nav-menu-item">
      <a class="nav-menu-parent has-menu nav0" role="menuitem" id="nav.studio" aria-haspopup="menu" aria-expanded="false">
        <span class="nav-menu-parent-text nav-menu-sparkle">Studio</span>
      </a>
      <div class="nav-menu-children" aria-hidden="true">
        <ul role="menu" aria-labelledby="nav.studio">
          <li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-studio-overview" href="/en/studio/overview">
            <span class="nav-menu-child-text">About Studio</span></a></li><li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-simulations-studio" href="/en/simulations/customize">
            <span class="nav-menu-child-text">Customizable Sims</span></a></li>
        </ul>
      </div>
    </li><li class="nav-menu-item">
      <a class="nav-menu-parent has-menu nav0" role="menuitem" id="nav.teaching" aria-haspopup="menu" aria-expanded="false">
        <span class="nav-menu-parent-text">Teaching</span>
      </a>
      <div class="nav-menu-children" aria-hidden="true">
        <ul role="menu" aria-labelledby="nav.teaching">
          <li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-teacherIdeas-browse" href="/en/activities">
            <span class="nav-menu-child-text">Activities</span></a></li><li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-teacherIdeas-submit" href="/en/activities/contribute">
            <span class="nav-menu-child-text">Contribute an Activity</span></a></li><li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-activities-contributionGuidelines" href="/en/activities/contribution-guidelines">
            <span class="nav-menu-child-text">Activity Contribution Guidelines</span></a></li><li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-virtualWorkshops" href="/en/teaching-resources/virtual-workshop/">
            <span class="nav-menu-child-text">Virtual Workshops</span></a></li><li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-forTeachers-tipsForUsingPhet" href="/en/teaching-resources/tipsForUsingPhet">
            <span class="nav-menu-child-text">Tips for Using PhET</span></a></li>
        </ul>
      </div>
    </li><li class="nav-menu-item">
      <a class="nav-menu-parent nav0" role="menuitem" href="/en/research">
        <span class="nav-menu-parent-text">Research</span>
      </a>
      <div class="nav-menu-children empty" aria-hidden="true">
        
      </div>
    </li><li class="nav-menu-item">
      <a class="nav-menu-parent has-menu nav0" role="menuitem" id="nav.initiatives" aria-haspopup="menu" aria-expanded="false">
        <span class="nav-menu-parent-text">Initiatives</span>
      </a>
      <div class="nav-menu-children" aria-hidden="true">
        <ul role="menu" aria-labelledby="nav.initiatives">
          <li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-inclusiveDesign" href="/en/inclusive-design">
            <span class="nav-menu-child-text">Inclusive Design</span></a></li><li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-phetGlobal" href="/en/phet-global">
            <span class="nav-menu-child-text">PhET Global</span></a></li><li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-deibInStemEd" href="/en/deib-in-stem-ed">
            <span class="nav-menu-child-text">DEIB in STEM Ed</span></a></li><li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-sceneryStackOse" href="/en/scenerystack-ose">
            <span class="nav-menu-child-text">SceneryStack OSE</span></a></li><li class="nav-menu-children-item">
            <a class="nav-menu-child" role="menuitem" tabindex="-1" id="nav-location-nav-phetImpact" href="/publications/PhET_Impact_Report_2024.pdf">
            <span class="nav-menu-child-text">Impact Report</span></a></li>
        </ul>
      </div>
    </li>
  </ul>

</nav>
          <div id="search" role="search">
            <div class="search-toggle-container">
<button id="search-toggle-button" aria-haspopup="menu" aria-expanded="false" aria-label="Search">
  <svg id="search-icon" style="display: block;" viewBox="-1 -1 100 100" xmlns="http://www.w3.org/2000/svg">
    <circle id="search-circle" class="search-shape" cx="30" cy="30" r="29"></circle>
    <line id="search-line" class="search-shape" x1="75" y1="75" x2="50" y2="50"></line>
  </svg>
  <svg id="x-icon" style="display: none;" viewBox="-1 -1 100 100" xmlns="http://www.w3.org/2000/svg">
    <line class="search-shape" x1="75" y1="75" x2="25" y2="25"></line>
    <line class="search-shape" x1="75" y1="25" x2="25" y2="75"></line>
  </svg>
</button>
</div>
            <div id="search-container-desktop" class="search-hidden" aria-hidden="true"></div>
          </div>
          <div id="user-menu" class="ltr">
            <div>
  <div id="loginout-list-parent">
    <div id="sign-in-placeholder">

      <div class="login-toggle">
        <button role="button"
                class="login-button loading">
          <svg class="user-icon loading" version="1.1" id="Layer_1" x="0px" y="0px" width="81px" height="81px"
               viewBox="0 0 81 81"
               enable-background="new 0 0 81 81" xml:space="preserve" xmlns="http://www.w3.org/2000/svg"
          >
          <g>
            <path d="M53.551,66H28.449c-5.418,0-9.057-3.548-9.057-8.827c0-11.339,4.127-17.841,11.325-17.841c0.673,0,1.248,0.382,2.203,1.017
              c1.672,1.112,4.471,2.971,8.079,2.971s6.407-1.858,8.08-2.971c0.955-0.635,1.529-1.017,2.202-1.017
              c7.198,0,11.325,6.502,11.325,17.841C62.607,62.452,58.968,66,53.551,66z M30.528,42.112c-7.268,0.157-8.358,9.483-8.358,15.061
              c0,3.786,2.347,6.05,6.279,6.05h25.102c3.932,0,6.279-2.264,6.279-6.05c0-5.577-1.091-14.903-8.357-15.061
              c-0.214,0.108-0.497,0.312-0.854,0.548c-1.809,1.201-5.171,3.437-9.618,3.437s-7.81-2.235-9.617-3.437
              C31.024,42.424,30.741,42.221,30.528,42.112z M41,40.838c-6.847,0-12.417-5.572-12.417-12.419S34.153,16,41,16
              s12.417,5.572,12.417,12.419S47.847,40.838,41,40.838z M41,18.777c-5.315,0-9.64,4.324-9.64,9.642c0,5.316,4.324,9.64,9.64,9.64
              s9.64-4.323,9.64-9.64C50.64,23.102,46.315,18.777,41,18.777z"/>
          </g>
        </svg>
        </button>
      </div>
      <li id="signed-out-placeholder" class="login-link nav-menu-item">
        <button class="nav-menu-parent">
          Sign in / Register
        </button>
      </li>
    </div>
    <div id="sign-in-button" style="display: none">

      <div class="login-toggle">
        <button id="login-button" class="login-button" role="button" aria-haspopup="dialog" aria-label="Sign In" title="Sign In">
          <svg class="user-icon" version="1.1" id="Layer_1" x="0px" y="0px" width="81px" height="81px"
               viewBox="0 0 81 81"
               enable-background="new 0 0 81 81" xml:space="preserve" xmlns="http://www.w3.org/2000/svg">
          <g>
            <path d="M53.551,66H28.449c-5.418,0-9.057-3.548-9.057-8.827c0-11.339,4.127-17.841,11.325-17.841c0.673,0,1.248,0.382,2.203,1.017
              c1.672,1.112,4.471,2.971,8.079,2.971s6.407-1.858,8.08-2.971c0.955-0.635,1.529-1.017,2.202-1.017
              c7.198,0,11.325,6.502,11.325,17.841C62.607,62.452,58.968,66,53.551,66z M30.528,42.112c-7.268,0.157-8.358,9.483-8.358,15.061
              c0,3.786,2.347,6.05,6.279,6.05h25.102c3.932,0,6.279-2.264,6.279-6.05c0-5.577-1.091-14.903-8.357-15.061
              c-0.214,0.108-0.497,0.312-0.854,0.548c-1.809,1.201-5.171,3.437-9.618,3.437s-7.81-2.235-9.617-3.437
              C31.024,42.424,30.741,42.221,30.528,42.112z M41,40.838c-6.847,0-12.417-5.572-12.417-12.419S34.153,16,41,16
              s12.417,5.572,12.417,12.419S47.847,40.838,41,40.838z M41,18.777c-5.315,0-9.64,4.324-9.64,9.642c0,5.316,4.324,9.64,9.64,9.64
              s9.64-4.323,9.64-9.64C50.64,23.102,46.315,18.777,41,18.777z"/>
          </g>
        </svg>
        </button>
      </div>
      <li id="signed-out-menuitem" class="login-link nav-menu-item">
        <button class="nav-menu-parent"
                id="mobile-login-button">
          Sign in / Register
        </button>
      </li>
    </div>

    <div id="signed-in-menu" style="display: none">
      <ul id="signed-in-menubar" role="menubar">
        <li id="signed-in-menu-item" class="nav-menu-item">
          <button class="nav-menu-parent has-menu"
                  role="menuitem"
                  aria-expanded="false"
                  aria-haspopup="menu">
            <span id="user-menu-label" class="account-text nav-menu-parent-text">
              My Account
            </span>
            <svg class='user-icon active'
                 version='1.1'
                 id='Layer_1'
                 x='0px'
                 y='0px'
                 width='81px'
                 height='81px'
                 viewBox='0 0 81 81'
                 enable-background='new 0 0 81 81'
                 xml:space='preserve' xmlns='http://www.w3.org/2000/svg'
                 aria-labelledby='user-menu-label'>
              <title>
                My Account
              </title>
              <g>
              <path d="M53.551,66H28.449c-5.418,0-9.057-3.548-9.057-8.827c0-11.339,4.127-17.841,11.325-17.841c0.673,0,1.248,0.382,2.203,1.017
                c1.672,1.112,4.471,2.971,8.079,2.971s6.407-1.858,8.08-2.971c0.955-0.635,1.529-1.017,2.202-1.017
                c7.198,0,11.325,6.502,11.325,17.841C62.607,62.452,58.968,66,53.551,66z M30.528,42.112c-7.268,0.157-8.358,9.483-8.358,15.061
                c0,3.786,2.347,6.05,6.279,6.05h25.102c3.932,0,6.279-2.264,6.279-6.05c0-5.577-1.091-14.903-8.357-15.061
                c-0.214,0.108-0.497,0.312-0.854,0.548c-1.809,1.201-5.171,3.437-9.618,3.437s-7.81-2.235-9.617-3.437
                C31.024,42.424,30.741,42.221,30.528,42.112z M41,40.838c-6.847,0-12.417-5.572-12.417-12.419S34.153,16,41,16
                s12.417,5.572,12.417,12.419S47.847,40.838,41,40.838z M41,18.777c-5.315,0-9.64,4.324-9.64,9.642c0,5.316,4.324,9.64,9.64,9.64
                s9.64-4.323,9.64-9.64C50.64,23.102,46.315,18.777,41,18.777z"/>
              </g>
            </svg>
          </button>
          <div class="nav-menu-children"
               id="loginout-list">
            <ul role="menu"
                aria-labelledby="user-menu-label">

              <li id="my-bookmarks-link" class="nav-menu-children-item" style="display: none">
                <a role="menuitem" tabindex="-1" class="nav-menu-child sign-in-links" href="/en/my-phet/my-bookmarks">
                  <span class="nav-menu-child-text">
                    My Bookmarks
                  </span>
                </a>
              </li>
              <li id="my-contributions-link" class="nav-menu-children-item" style="display: none">
                <a role="menuitem" tabindex="-1" class="nav-menu-child sign-in-links" href="/en/my-phet/my-contributions">
                  <span class="nav-menu-child-text">
                    My Contributions
                  </span>
                </a>
              </li>
              <li id="my-presets-link" class="nav-menu-children-item" style="display: none">
                <a role="menuitem" tabindex="-1" class="nav-menu-child sign-in-links" href="/en/my-phet/my-presets">
                  <span class="nav-menu-child-text">
                    My Presets
                  </span>
                </a>
              </li>

              <div class="nav-menu-separator">
                  <!-- Empty by design-->
              </div>

              <li id="admin-link" class="nav-menu-children-item" style="display: none">
                <a role="menuitem"
                   tabindex="-1"
                   class="nav-menu-child sign-in-links"
                   href="/admin/main">
                  <span class="nav-menu-child-text">Administration</span>
                </a>
              </li>
              <li id="activity-editor-link" class="nav-menu-children-item" style="display: none">
                <a role="menuitem" tabindex="-1" class="nav-menu-child sign-in-links" href="/en/activities/manage">
                  <span class="nav-menu-child-text">Activity Review</span>
                </a>
              </li>
              <li class="nav-menu-children-item">
                <a role="menuitem" tabindex="-1" class="nav-menu-child sign-in-links" id="edit-profile-link" href="/en/edit-profile?dest=%2Ferror%2F404">
                <span class="nav-menu-child-text">
                  Edit profile
                </span>
                </a>
              </li>

              <div class="nav-menu-separator">
                <!-- Empty by design-->
              </div>

              <li class="nav-menu-children-item">
                <button role="menuitem"
                        tabindex="-1"
                        class="nav-menu-child sign-in-links"
                        onclick="window.logout()">
                  <span class="nav-menu-child-text">Sign out</span>
                </button>
              </li>
            </ul>
          </div>
        </li>
      </ul>
    </div>


    <div id="profileUpdateAsk" style="display: none;" class="profile-update-ask">
      <div class="profile-update-img">
        <img src="/images/Update_profile_popup.png" alt=""/>
        <div class="profile-update-title">
          Time to update!
        </div>
      </div>

      <div class="profile-update-right">
        <div class="profile-update-text">
          We are working to improve the usability of our website. To support this effort, please update your profile!
        </div>

        <div class="profile-update-buttons">
          <div id="profile-update-skip" class="phet-button">
            Skip for now
          </div>

          <a class="profile-update-link phet-button" href="/en/edit-profile?dest=%2Ferror%2F404">
            Update Profile
          </a>
        </div>
      </div>
    </div>

    
  </div>
</div>
            <div style="display:none;">
              <!DOCTYPE html>
<html>
<head>

<link rel="stylesheet" href="/_m/css/font-awesome/css/font-awesome.min-4.7.css"/>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
      href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
      rel="stylesheet">
<title data-rh="true"></title><meta data-rh="true" name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/><link data-rh="true" rel="shortcut icon" href="/favicon.ico"/><link data-rh="true" rel="stylesheet" type="text/css" href="/assets/css/phet-app56.css"/>
</head>
<body><script type="text/javascript">
  history.scrollRestoration = 'manual';
</script>
<div id="app" class="react-app"><dialog aria-label="Sign In" class="phet-modal-dialog"></dialog><div></div><div class="hidden"></div></div>
  <script type="text/javascript">__meteor_runtime_config__ = JSON.parse(decodeURIComponent("%7B%22meteorRelease%22%3A%22METEOR%403.1%22%2C%22gitCommitHash%22%3A%22a1139aaae14b7b1aec6c15fd3cd024815335804b%22%2C%22meteorEnv%22%3A%7B%22NODE_ENV%22%3A%22production%22%2C%22TEST_METADATA%22%3A%22%7B%7D%22%7D%2C%22PUBLIC_SETTINGS%22%3A%7B%22meteorOrigin%22%3A%22https%3A%2F%2Fphet.colorado.edu%22%2C%22commonInfoCookie%22%3A%22phet-common-info%22%2C%22backendMode%22%3A%22PRIMARY%22%2C%22directOrigin%22%3A%22https%3A%2F%2Fphet-direct.colorado.edu%22%2C%22CLEVER_ID%22%3A%22de6371c62cab4cc1ae29%22%2C%22shouldShowDemoPages%22%3Afalse%7D%2C%22debug%22%3Afalse%2C%22ROOT_URL%22%3A%22https%3A%2F%2Fphet.colorado.edu%2F_m%22%2C%22ROOT_URL_PATH_PREFIX%22%3A%22%2F_m%22%2C%22reactFastRefreshEnabled%22%3Atrue%2C%22autoupdate%22%3A%7B%22versions%22%3A%7B%22web.browser%22%3A%7B%22version%22%3A%22dffbac094cdf80605b309c8b0eca1ce11263101d%22%2C%22versionRefreshable%22%3A%22d8572a3ed225b9a773092f01fa9f7af3b28ee7f2%22%2C%22versionNonRefreshable%22%3A%22dffbac094cdf80605b309c8b0eca1ce11263101d%22%2C%22versionReplaceable%22%3A%22d8572a3ed225b9a773092f01fa9f7af3b28ee7f2%22%7D%7D%2C%22autoupdateVersion%22%3Anull%2C%22autoupdateVersionRefreshable%22%3Anull%2C%22autoupdateVersionCordova%22%3Anull%2C%22appId%22%3A%221g31nnl1vm0td1ez71tp%22%7D%2C%22appId%22%3A%221g31nnl1vm0td1ez71tp%22%2C%22isModern%22%3Atrue%7D"))</script>

  <script type="text/javascript" src="/_m/7583a559f419bf1178d6cb2a55cda5f991cf1a2f.js?meteor_js_resource=true"></script>


<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"rayId":"9583107e2af40970","version":"2025.6.2","serverTiming":{"name":{"cfExtPri":true,"cfEdge":true,"cfOrigin":true,"cfL4":true,"cfSpeedBrain":true,"cfCacheStatus":true}},"token":"57ed97624d4c401fb934c2dd728ace72","b":1}' crossorigin="anonymous"></script>
</body>
</html>
            </div>
          </div>
        </div>
      </div>
    </header>
  </div>

</div>

<!--This is a temporary placeholder-->
<div style="display: none;">
  <div id="page-nav-search" role="search" class="page-header-search">
  <form method="get" id="search-form" class="autocompleteOff" action="/en/search">
    <div id="search-form-container">
      <label for="search-text-id" class="hidden">
        Search the PhET Website
      </label>
      <div class="search-box">
        <input type="text" size="15" name="q" class="always-enabled acInput" id="search-text-id" tabindex="-1" placeholder="Search..."/>
        <button type="submit" form="search-form" id="search-submit" class="always-enabled autocompleteOff" tabindex="-1" title="Click here to search the PhET website">
          <img id="magnifying-glass" src="/images/icons/search-icon.png" alt="Search"/>
        </button>
      </div>
    </div>
  </form>
</div>
</div>

<div id="page-content" role="main" class="page-content">
  
  <h1 style="text-align: center;">
    The requested page could not be found.
  </h1>
  <img src="/images/phetgirl_404.png" style="margin: 0 auto; display: block; width: 300px;" alt="">

</div>

<div id="page-footer" class="ltr">
  <footer>
    <div class="main-footer">
      <div class="social-footer">
  
    <hr>
    <div id="social-footer" dir="ltr">
      <span>
        <a class="footer-link" href="https://www.facebook.com/pages/PhET-Interactive-Simulations/161503243888932?v=wall" rel="external nofollow" title="Like us on Facebook" aria-label="Like us on Facebook" dir="ltr">
          <i class="fa fa-facebook"></i>
        </a>
      </span><span>
        <a class="footer-link" href="https://twitter.com/PhETSims" rel="external nofollow" title="Follow us on Twitter" aria-label="Follow us on Twitter" dir="ltr">
          <i class="fa fa-twitter"></i>
        </a>
      </span><span>
        <a class="footer-link" href="https://www.linkedin.com/company/phet-interactive-simulations" rel="external nofollow" title="LinkedIn" aria-label="LinkedIn" dir="ltr">
          <i class="fa fa-linkedin"></i>
        </a>
      </span><span>
        <a class="footer-link" href="https://www.instagram.com/phetsims/" rel="external nofollow" title="Follow us on Instagram" aria-label="Follow us on Instagram" dir="ltr">
          <i class="fa fa-instagram"></i>
        </a>
      </span><span>
        <a class="footer-link" href="https://www.youtube.com/channel/UCMRZ0-ci4ifGBF1bJvrcDRQ" rel="external nofollow" title="Watch us on Youtube" aria-label="Watch us on Youtube" dir="ltr">
          <i class="fa fa-youtube-play"></i>
        </a>
      </span>
    </div>
    <hr>
  
</div>
      <div id="footer-nav-links">
        <div>
          <a class="floating-link" href="/en/about"><span>About PhET</span></a>
          <a class="floating-link" href="/en/about/team"><span>Our Team</span></a>
          <a class="floating-link" href="/en/our-supporters"><span>Our Supporters</span></a>
          <a class="floating-link" href="/en/partnerships"><span>Partnerships</span></a>
        </div>
        <div>
          <a class="floating-link" href="/en/simulations/filter?type=html&amp;a11yFeatures=accessibility"><span>Accessibility</span></a>
          <a class="floating-link" href="/en/offline-access"><span>Offline Access</span></a>
          <a class="floating-link" href="/en/help-center/getting-started"><span>Help Center</span></a>
          <a class="floating-link" href="/en/privacy-policy"><span>Privacy Policy</span></a>
        </div>
        <div>
          <a class="floating-link" href="/en/about/source-code"><span>Source Code</span></a>
          <a class="floating-link" href="/en/licensing"><span>Licensing</span></a>
          <a class="floating-link" href="/en/for-translators"><span>For Translators</span></a>
          <a class="floating-link" href="/en/about/contact"><span>Contact</span></a>
        </div>
      </div>
      <div class="other-languages">
        <div class="translation-links">
  
    <span class="globe"><i class="fa fa-globe"></i></span>

    <select id="translation-links" name="body:footer:translation-links:translation-links" aria-label="Choose Language">
<option selected="selected" value="en">English</option>
<option value="ar_SA">العربية</option>
<option value="az">Azərbaycanca</option>
<option value="eu">Euskara</option>
<option value="be">Беларуская</option>
<option value="bs">Bosanski</option>
<option value="zh_CN">简体中文</option>
<option value="zh_TW">正體中文</option>
<option value="hr">Hrvatski</option>
<option value="cs">Česky</option>
<option value="da">Dansk</option>
<option value="nl">Nederlands</option>
<option value="et">Eesti</option>
<option value="fi">Suomi</option>
<option value="fr">Français</option>
<option value="gl">Galego</option>
<option value="ka">ქართული</option>
<option value="de">Deutsch</option>
<option value="el">Ελληνικά</option>
<option value="gu">અંગ્રેજી</option>
<option value="hu">Magyar</option>
<option value="in">Bahasa Indonesia</option>
<option value="it">Italiano</option>
<option value="ja">日本語</option>
<option value="ko">한국어</option>
<option value="ku">كوردي</option>
<option value="ku_TR">Kurdî</option>
<option value="lt">Lietuvių</option>
<option value="mk">Македонски</option>
<option value="mr">मराठी</option>
<option value="mn">Монгол</option>
<option value="nb">Norsk bokmål</option>
<option value="nn">Norsk nynorsk</option>
<option value="fa">فارسی</option>
<option value="pl">polski</option>
<option value="pt">Português</option>
<option value="pt_BR">Português do Brasil</option>
<option value="ro">Română</option>
<option value="sr">Српски</option>
<option value="si">සිංහල</option>
<option value="sk">Slovensky</option>
<option value="es">Español</option>
<option value="es_PE">Español Latinoamérica</option>
<option value="th">ไทย</option>
<option value="tr">Türkçe</option>
<option value="uk">Українська</option>
<option value="uz">Oʻzbekcha</option>
<option value="vi">Tiếng Việt</option>
</select>
  

  <span style="display: none;">
      <a href="/en/"><span class="current-locale">English</span></a>
  </span><span style="display: none;">
      <a href="/ar_SA/"><span>العربية</span></a>
  </span><span style="display: none;">
      <a href="/az/"><span>Azərbaycanca</span></a>
  </span><span style="display: none;">
      <a href="/eu/"><span>Euskara</span></a>
  </span><span style="display: none;">
      <a href="/be/"><span>Беларуская</span></a>
  </span><span style="display: none;">
      <a href="/bs/"><span>Bosanski</span></a>
  </span><span style="display: none;">
      <a href="/zh_CN/"><span>简体中文</span></a>
  </span><span style="display: none;">
      <a href="/zh_TW/"><span>正體中文</span></a>
  </span><span style="display: none;">
      <a href="/hr/"><span>Hrvatski</span></a>
  </span><span style="display: none;">
      <a href="/cs/"><span>Česky</span></a>
  </span><span style="display: none;">
      <a href="/da/"><span>Dansk</span></a>
  </span><span style="display: none;">
      <a href="/nl/"><span>Nederlands</span></a>
  </span><span style="display: none;">
      <a href="/et/"><span>Eesti</span></a>
  </span><span style="display: none;">
      <a href="/fi/"><span>Suomi</span></a>
  </span><span style="display: none;">
      <a href="/fr/"><span>Français</span></a>
  </span><span style="display: none;">
      <a href="/gl/"><span>Galego</span></a>
  </span><span style="display: none;">
      <a href="/ka/"><span>ქართული</span></a>
  </span><span style="display: none;">
      <a href="/de/"><span>Deutsch</span></a>
  </span><span style="display: none;">
      <a href="/el/"><span>Ελληνικά</span></a>
  </span><span style="display: none;">
      <a href="/gu/"><span>અંગ્રેજી</span></a>
  </span><span style="display: none;">
      <a href="/hu/"><span>Magyar</span></a>
  </span><span style="display: none;">
      <a href="/in/"><span>Bahasa Indonesia</span></a>
  </span><span style="display: none;">
      <a href="/it/"><span>Italiano</span></a>
  </span><span style="display: none;">
      <a href="/ja/"><span>日本語</span></a>
  </span><span style="display: none;">
      <a href="/ko/"><span>한국어</span></a>
  </span><span style="display: none;">
      <a href="/ku/"><span>كوردي</span></a>
  </span><span style="display: none;">
      <a href="/ku_TR/"><span>Kurdî</span></a>
  </span><span style="display: none;">
      <a href="/lt/"><span>Lietuvių</span></a>
  </span><span style="display: none;">
      <a href="/mk/"><span>Македонски</span></a>
  </span><span style="display: none;">
      <a href="/mr/"><span>मराठी</span></a>
  </span><span style="display: none;">
      <a href="/mn/"><span>Монгол</span></a>
  </span><span style="display: none;">
      <a href="/nb/"><span>Norsk bokmål</span></a>
  </span><span style="display: none;">
      <a href="/nn/"><span>Norsk nynorsk</span></a>
  </span><span style="display: none;">
      <a href="/fa/"><span>فارسی</span></a>
  </span><span style="display: none;">
      <a href="/pl/"><span>polski</span></a>
  </span><span style="display: none;">
      <a href="/pt/"><span>Português</span></a>
  </span><span style="display: none;">
      <a href="/pt_BR/"><span>Português do Brasil</span></a>
  </span><span style="display: none;">
      <a href="/ro/"><span>Română</span></a>
  </span><span style="display: none;">
      <a href="/sr/"><span>Српски</span></a>
  </span><span style="display: none;">
      <a href="/si/"><span>සිංහල</span></a>
  </span><span style="display: none;">
      <a href="/sk/"><span>Slovensky</span></a>
  </span><span style="display: none;">
      <a href="/es/"><span>Español</span></a>
  </span><span style="display: none;">
      <a href="/es_PE/"><span>Español Latinoamérica</span></a>
  </span><span style="display: none;">
      <a href="/th/"><span>ไทย</span></a>
  </span><span style="display: none;">
      <a href="/tr/"><span>Türkçe</span></a>
  </span><span style="display: none;">
      <a href="/uk/"><span>Українська</span></a>
  </span><span style="display: none;">
      <a href="/uz/"><span>Oʻzbekcha</span></a>
  </span><span style="display: none;">
      <a href="/vi/"><span>Tiếng Việt</span></a>
  </span>

  <div style="display: none" id="locale" locale="en"></div>


</div>
        
      </div>

      <div id="app-badges">
      <span>
  <a href="https://apps.apple.com/us/app/phet-simulations/id1134126831" style="text-decoration: none; display: inline-block;">
    <img style="width: 120px;" alt="Download on the App Store" src="/images/ios-app-store-badges/US/badge.svg"/>
  </a>
</span>
        <span>
        <a style="text-decoration: none; display: inline-block;"
           href="https://play.google.com/store/apps/details?id=edu.colorado.phet.androidApp"
           aria-label="Get it on Google Play">
          <img src="/images/play_store_badge.png" style="width: 120px;" alt="Google Play Badge"></a>
      </span>
      </div>

      <div class="apps-for-schools">
        <a class="link-button" href="/en/apps-for-schools">
          <img src="/images/devices.svg" alt=""/>
          <p>Get Apps for Schools</p>
        </a>
      </div>

    </div>
    <div class="footer-highlight-background">
      <div class="footer-bottom">
        <div class="left">
          <table>
            <tr>
              <td class="sponsor">
                <a href="http://www.moore.org/" rel="external" dir="ltr">
                  <img src="/images/support/Moore_Foundation_logo_footer-01.png"
                       alt="Moore Foundation" width="100"/>
                </a>
              </td>
              <td class="sponsor">
                <a href="http://www.nsf.gov/" rel="external" dir="ltr">
                  <img src="/images/support/NSF_logo_footer-01.png"
                       alt="National Science Foundation" width="56"/>
                </a>
              </td>
              <td class="sponsor">
                <a href="http://www.hewlett.org/" rel="external" dir="ltr">
                  <img src="/images/support/hewlett-greyscale.svg"
                       alt="Hewlett Foundation" width="100"/>
                </a>
              </td>
              <td class="sponsor">
                <a href="https://yidanprize.org/" rel="external" dir="ltr">
                  <img src="/images/support/yidan-footer.png"
                       alt="Yidan Prize" width="54"/>
                </a>
              </td>
              <td class="sponsor">
                <a href="https://mastercardfdn.org/" rel="external" dir="ltr">
                  <img src="/images/support/mastercard-footer.svg"
                       alt="Mastercard Foundation" width="54"/>
                </a>
              </td>
            </tr>
          </table>
        </div>
        <div class="right">
          <div id="PhET-logo">
            <a href="/">
              <img src="/images/phet-logo-trademarked-black.png" alt="PhET Home Page" title="Go to the PhET home page"
                   style="border: none;"
                   width="90" id="phet-logo-main-image">
            </a>
          </div>
          <div class="copyright">
            <a href="/en/licensing">
              <span>&copy;<span>2025 University of Colorado. </span></span>
              <br/>
              Some rights reserved.
            </a>
          </div>
        </div>
      </div>
    </div>
  </footer>
</div>

<!--This section only shows up on IE and tells the user to switch to a real browser-->
<div id="ie11Blocker">
  <div class="modal">
    <p>
      The PhET website does not support your browser. We recommend using the latest version of Chrome, Firefox, Safari, or Edge.
    </p>
    <button id="ie11Blocker-close">
      <i class="fa fa-times"></i>
    </button>
  </div>

  <script>
    document.getElementById( 'ie11Blocker' ).addEventListener( 'click', function() {
      document.getElementById( 'ie11Blocker' ).style.display = 'none';
    } );
  </script>
</div>

<script type="text/javascript" src="/js/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="https://phet.colorado.edu/js/phet-v62-min.js" async="true"></script>
</body>
</html>

